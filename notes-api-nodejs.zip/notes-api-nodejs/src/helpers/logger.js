import consola from 'consola'

const logger = consola

export default logger
