import dotenv from 'dotenv'

dotenv.config()
